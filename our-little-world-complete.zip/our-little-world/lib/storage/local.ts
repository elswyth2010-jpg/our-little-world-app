import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

const root = path.join(process.cwd(), "storage", "private-media");

export async function savePrivateFile(file: File) {
  const bytes = Buffer.from(await file.arrayBuffer());
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-120) || "upload";
  const key = `${crypto.randomUUID()}-${safeName}`;
  await fs.mkdir(root, { recursive: true });
  await fs.writeFile(path.join(root, key), bytes);
  return { storageKey: key, sizeBytes: bytes.length };
}

export async function readPrivateFile(storageKey: string) {
  const safeKey = path.basename(storageKey);
  return fs.readFile(path.join(root, safeKey));
}

export async function deletePrivateFile(storageKey: string) {
  const safeKey = path.basename(storageKey);
  await fs.rm(path.join(root, safeKey), { force: true });
}

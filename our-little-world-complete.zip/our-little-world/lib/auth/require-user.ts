import { redirect } from "next/navigation";
import { db } from "@/lib/db/prisma";
import { getSessionUserId } from "@/lib/auth/session";

export async function requireUser() {
  const userId = await getSessionUserId();
  if (!userId) redirect("/login");

  const user = await db.user.findUnique({ where: { id: userId } });
  if (!user) redirect("/login");

  return user;
}

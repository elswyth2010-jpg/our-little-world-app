import { Visibility } from "@prisma/client";

export function canReadContent(params: {
  currentUserId: string;
  authorId: string;
  visibility: Visibility;
  status: "ACTIVE" | "ARCHIVED" | "TRASHED";
}) {
  if (params.status === "TRASHED") return params.currentUserId === params.authorId;
  if (params.currentUserId === params.authorId) return true;
  return params.visibility === Visibility.SHARED;
}

export function canModifyContent(currentUserId: string, authorId: string) {
  return currentUserId === authorId;
}

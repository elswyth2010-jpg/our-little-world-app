import { PrismaClient } from "@prisma/client";
import { hash } from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const password = process.env.SEED_PASSWORD;
  if (!password || password.length < 12) {
    throw new Error("Set SEED_PASSWORD to a temporary password of at least 12 characters before seeding.");
  }

  const passwordHash = await hash(password, 12);

  await db.user.upsert({
    where: { email: "you@example.com" },
    update: {},
    create: { name: "You", email: "you@example.com", passwordHash }
  });

  await db.user.upsert({
    where: { email: "her@example.com" },
    update: {},
    create: { name: "Her", email: "her@example.com", passwordHash }
  });

  console.log("Two starter accounts created/verified.");
}

main().finally(() => db.$disconnect());

# Our Little World

A private, two-person diary and memory space with a **Vintage Diary** default theme and five alternate themes.

## Included

- Private/shared diary entries, memories, timeline events, and songs
- Photo, video, and audio attachments on memories (stored locally under `storage/private-media`)
- Future plans with Dreaming / Planned / Completed stages and a completed-plan-to-memory flow
- The **Us** page: shared story, important dates, favorites, and dreams
- Six themes: Vintage Diary, Midnight, Sakura, Dreamy, Ocean, and Minimal
- Archive, Trash, restore, and manual permanent-delete actions for supported content
- Session-cookie authentication and owner/visibility checks

## Requirements

- Node.js 20 or newer
- PostgreSQL 14 or newer
- npm

## First-time setup

1. Create a PostgreSQL database named `our_little_world` (or choose another name and update `DATABASE_URL`).
2. Copy `.env.example` to `.env` and set `DATABASE_URL` and a unique `SESSION_SECRET` of at least 32 characters. Set `SEED_PASSWORD` to a temporary password of at least 12 characters if you plan to use the starter accounts.
3. In this folder, run:

   ```bash
   npm install
   npx prisma generate
   npx prisma migrate dev --name initial_setup
   npm run seed
   npm run dev
   ```

4. Open `http://localhost:3000`. The seed command creates `you@example.com` and `her@example.com` with the temporary password from `SEED_PASSWORD`. Both accounts initially share that password, so change this before using the app with real personal content. Do not run the seed command on a production database.

To start without sample accounts, skip `npm run seed` and create the user records through your own trusted setup process. This snapshot currently has login but no public sign-up flow.

## Useful commands

```bash
npm run dev       # development server
npm run build     # production build
npm start         # serve the production build
npm run lint      # ESLint
npm run db:generate
npm run db:migrate
npm run db:studio
npm run seed
```

## Data and privacy notes

- Database records are stored in PostgreSQL. Uploaded media is stored on the local filesystem in `storage/private-media`; back up both the database and that folder.
- Local media storage is intended for a single-machine/local deployment. For multi-instance hosting, use private object storage and configure access controls before deployment.
- Deleted content is moved to Trash and can be restored or permanently deleted manually. The UI displays a 30-day retention period, but this snapshot does **not** include an automatically scheduled purge job; set one up before relying on automatic deletion.
- Do not commit `.env`, uploaded media, or real user data to source control.

## Before production

- Configure a managed PostgreSQL database, HTTPS, strong unique secrets, and private persistent media storage.
- Change the starter passwords and avoid running the seed script in production.
- Add a scheduled 30-day Trash cleanup job if automatic expiry is required.
- Test account isolation, media access, restore/delete flows, and backups in your own environment.

## Build verification

The project ZIP is assembled from the cumulative Part 8 snapshot. Dependency installation/build could not be completed in the packaging environment, so run the setup and `npm run build` locally and resolve any environment-specific issues before deploying.

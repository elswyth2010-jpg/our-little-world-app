import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { DiaryActions } from "@/components/diary-actions";

export default async function DiaryPage({ searchParams }: { searchParams: Promise<{ filter?: string; q?: string }> }) {
  const user = await requireUser();
  const params = await searchParams;
  const filter = params.filter ?? "all";
  const q = params.q?.trim() ?? "";

  const entries = await prisma.diaryEntry.findMany({
    where: {
      status: "ACTIVE",
      AND: [
        { OR: [{ authorId: user.id }, { visibility: "SHARED" }] },
        q ? { OR: [{ title: { contains: q, mode: "insensitive" } }, { content: { contains: q, mode: "insensitive" } }] } : {},
        filter === "mine" ? { authorId: user.id } : {},
        filter === "hers" ? { authorId: { not: user.id } } : {},
        filter === "shared" ? { visibility: "SHARED" } : {}
      ]
    },
    orderBy: { entryDate: "desc" },
    include: { author: { select: { id: true, name: true } }, favorites: { where: { userId: user.id }, select: { id: true } } }
  });

  const shown = filter === "favorites" ? entries.filter((entry) => entry.favorites.length > 0) : entries;
  return (
    <main className="app-shell">
      <header className="topbar"><Link className="brand" href="/home">Our Little World</Link><nav><Link href="/home">Home</Link><Link className="active" href="/diary">Diary</Link><Link href="/plans">Future</Link><Link href="/us">Us</Link><Link href="/trash">Trash</Link></nav><Link className="button small-button" href="/diary/new">+ New entry</Link></header>
      <section className="content-wrap">
        <div className="page-heading"><div><p className="eyebrow">Our pages</p><h1>Diary</h1><p className="muted">The little things, the big things, and everything in between.</p></div><form className="search-form"><input name="q" defaultValue={q} placeholder="Search your diary…" /><button className="secondary-button" type="submit">Search</button></form></div>
        <div className="filter-row">{[["all","All"],["mine","Mine"],["hers","Hers"],["shared","Shared"],["favorites","Favorites"]].map(([value,label]) => <Link key={value} className={`filter-pill ${filter===value?"selected":""}`} href={`/diary?filter=${value}${q ? `&q=${encodeURIComponent(q)}` : ""}`}>{label}</Link>)}</div>
        <div className="entry-list">
          {shown.length === 0 ? <div className="empty-state"><span>✦</span><h2>No pages here yet</h2><p>Start with something small. It doesn’t have to be important to be worth remembering.</p><Link className="button" href="/diary/new">Write the first page</Link></div> : shown.map((entry) => <article className="diary-card" key={entry.id}><div className="entry-date">{entry.entryDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</div><div className="entry-main"><div className="entry-meta"><span>{entry.authorId === user.id ? "Added by you" : `Added by ${entry.author.name}`}</span><span>•</span><span>{entry.visibility === "SHARED" ? "Shared" : "Private"}</span></div><h2>{entry.title}</h2><p>{entry.content.length > 260 ? `${entry.content.slice(0,260)}…` : entry.content}</p></div><DiaryActions id={entry.id} favorite={entry.favorites.length > 0} canManage={entry.authorId === user.id} /></article>)}
        </div>
      </section>
    </main>
  );
}

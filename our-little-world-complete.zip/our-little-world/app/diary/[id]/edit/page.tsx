import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { DiaryForm } from "@/components/diary-form";

export default async function EditDiaryPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireUser();
  const { id } = await params;
  const entry = await prisma.diaryEntry.findUnique({ where: { id } });
  if (!entry || entry.authorId !== user.id || entry.status === "TRASHED") notFound();
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><Link className="secondary-button" href="/diary">← Back to diary</Link></header><section className="form-wrap"><p className="eyebrow">Edit page</p><h1>Make a change</h1><DiaryForm mode="edit" id={id} initial={{ title: entry.title, content: entry.content, visibility: entry.visibility, entryDate: entry.entryDate.toISOString().slice(0,10) }} /></section></main>;
}

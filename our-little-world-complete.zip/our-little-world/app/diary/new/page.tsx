import Link from "next/link";
import { requireUser } from "@/lib/auth/require-user";
import { DiaryForm } from "@/components/diary-form";

export default async function NewDiaryPage() {
  await requireUser();
  const today = new Date().toISOString().slice(0, 10);
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><Link className="secondary-button" href="/diary">← Back to diary</Link></header><section className="form-wrap"><p className="eyebrow">A new page</p><h1>Write a diary entry</h1><p className="muted intro">There’s no perfect way to remember a moment. Just write it as it felt.</p><DiaryForm mode="create" initial={{ title: "", content: "", visibility: "PRIVATE", entryDate: today }} /></section></main>;
}

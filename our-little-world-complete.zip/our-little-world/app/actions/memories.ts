"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { savePrivateFile, deletePrivateFile } from "@/lib/storage/local";

const schema = z.object({
  title: z.string().trim().min(1).max(160),
  description: z.string().trim().max(10000).optional().default(""),
  visibility: z.enum(["PRIVATE", "SHARED"]),
  memoryDate: z.string().min(1),
  diaryEntryIds: z.array(z.string()).default([])
});

function filesFrom(formData: FormData) {
  return formData.getAll("media").filter((v): v is File => v instanceof File && v.size > 0);
}

function mediaType(file: File) {
  if (file.type.startsWith("image/")) return "IMAGE";
  if (file.type.startsWith("video/")) return "VIDEO";
  if (file.type.startsWith("audio/")) return "AUDIO";
  throw new Error("Only image, video, and audio files are supported.");
}

async function createMedia(ownerId: string, memoryId: string, file: File) {
  if (file.size > 20 * 1024 * 1024) throw new Error("Each media file must be 20MB or smaller.");
  const type = mediaType(file);
  const saved = await savePrivateFile(file);
  return prisma.media.create({
    data: { ownerId, memoryId, type, storageKey: saved.storageKey, filename: file.name.slice(0, 255), mimeType: file.type || "application/octet-stream", sizeBytes: BigInt(saved.sizeBytes) }
  });
}

export async function createMemory(formData: FormData) {
  const user = await requireUser();
  const data = schema.parse({
    title: formData.get("title"),
    description: formData.get("description") ?? "",
    visibility: formData.get("visibility"),
    memoryDate: formData.get("memoryDate"),
    diaryEntryIds: formData.getAll("diaryEntryIds").map(String)
  });
  const memoryDate = new Date(`${data.memoryDate}T12:00:00`);
  if (Number.isNaN(memoryDate.getTime())) throw new Error("Invalid memory date");

  const visibleDiary = await prisma.diaryEntry.findMany({ where: { id: { in: data.diaryEntryIds }, status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, select: { id: true } });
  const allowedIds = new Set(visibleDiary.map((e) => e.id));
  const files = filesFrom(formData);
  const created = await prisma.memory.create({
    data: { authorId: user.id, title: data.title, description: data.description || null, visibility: data.visibility, memoryDate, diaryLinks: { create: data.diaryEntryIds.filter((id) => allowedIds.has(id)).map((diaryEntryId) => ({ diaryEntryId })) } }
  });
  try {
    for (const file of files) await createMedia(user.id, created.id, file);
  } catch (error) {
    await prisma.memory.delete({ where: { id: created.id } });
    throw error;
  }
  revalidatePath("/memories"); revalidatePath("/home");
  redirect("/memories");
}

export async function deleteMemoryMedia(mediaId: string) {
  const user = await requireUser();
  const media = await prisma.media.findUnique({ where: { id: mediaId }, include: { memory: { select: { authorId: true } } } });
  if (!media || media.ownerId !== user.id || media.memory?.authorId !== user.id) throw new Error("Not allowed");
  await deletePrivateFile(media.storageKey);
  await prisma.media.delete({ where: { id: mediaId } });
  revalidatePath("/memories");
}

export async function archiveMemory(id: string) {
  const user = await requireUser();
  const memory = await prisma.memory.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!memory || memory.authorId !== user.id) throw new Error("Not allowed");
  if (memory.status !== "ACTIVE") return;
  await prisma.memory.update({ where: { id }, data: { status: "ARCHIVED", archivedAt: new Date() } });
  revalidatePath("/memories");
}

export async function deleteMemory(id: string) {
  const user = await requireUser();
  const memory = await prisma.memory.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!memory || memory.authorId !== user.id) throw new Error("Not allowed");
  await prisma.memory.update({ where: { id }, data: { status: "TRASHED", deletedAt: new Date() } });
  revalidatePath("/memories");
}

export async function restoreMemory(id: string) {
  const user = await requireUser();
  const memory = await prisma.memory.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!memory || memory.authorId !== user.id) throw new Error("Not allowed");
  if (memory.status !== "TRASHED" && memory.status !== "ARCHIVED") return;
  await prisma.memory.update({ where: { id }, data: { status: "ACTIVE", archivedAt: null, deletedAt: null } });
  revalidatePath("/memories"); revalidatePath("/trash");
}

export async function permanentlyDeleteMemory(id: string) {
  const user = await requireUser();
  const memory = await prisma.memory.findUnique({ where: { id }, include: { media: true } });
  if (!memory || memory.authorId !== user.id || memory.status !== "TRASHED") throw new Error("Not allowed");
  for (const media of memory.media) await deletePrivateFile(media.storageKey);
  await prisma.memory.delete({ where: { id } });
  revalidatePath("/trash");
}

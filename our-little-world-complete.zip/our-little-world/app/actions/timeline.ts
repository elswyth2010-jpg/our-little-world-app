"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";

const schema = z.object({
  title: z.string().trim().min(1).max(160),
  description: z.string().trim().max(10000).optional().default(""),
  eventDate: z.string().min(1),
  category: z.string().trim().max(40).optional().default("MILESTONE"),
  visibility: z.enum(["PRIVATE", "SHARED"]),
  diaryEntryIds: z.array(z.string()).default([]),
  memoryIds: z.array(z.string()).default([]),
  songIds: z.array(z.string()).default([])
});

export async function createTimelineEvent(formData: FormData) {
  const user = await requireUser();
  const data = schema.parse({
    title: formData.get("title"), description: formData.get("description") ?? "",
    eventDate: formData.get("eventDate"), category: formData.get("category") ?? "MILESTONE",
    visibility: formData.get("visibility"),
    diaryEntryIds: formData.getAll("diaryEntryIds").map(String),
    memoryIds: formData.getAll("memoryIds").map(String),
    songIds: formData.getAll("songIds").map(String)
  });
  const eventDate = new Date(`${data.eventDate}T12:00:00`);
  if (Number.isNaN(eventDate.getTime())) throw new Error("Invalid timeline date");

  const [diaries, memories, songs] = await Promise.all([
    prisma.diaryEntry.findMany({ where: { id: { in: data.diaryEntryIds }, status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, select: { id: true } }),
    prisma.memory.findMany({ where: { id: { in: data.memoryIds }, status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, select: { id: true } }),
    prisma.song.findMany({ where: { id: { in: data.songIds }, status: "ACTIVE", OR: [{ addedById: user.id }, { visibility: "SHARED" }] }, select: { id: true } })
  ]);

  const created = await prisma.timelineEvent.create({
    data: {
      authorId: user.id, title: data.title, description: data.description || null, eventDate,
      category: data.category || "MILESTONE", visibility: data.visibility,
      diaryLinks: { create: diaries.map(({ id }) => ({ diaryEntryId: id })) },
      memoryLinks: { create: memories.map(({ id }) => ({ memoryId: id })) },
      songLinks: { create: songs.map(({ id }) => ({ songId: id })) }
    }
  });
  revalidatePath("/timeline"); revalidatePath("/home");
  redirect("/timeline");
}

export async function archiveTimelineEvent(id: string) {
  const user = await requireUser();
  const event = await prisma.timelineEvent.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!event || event.authorId !== user.id) throw new Error("Not allowed");
  if (event.status !== "ACTIVE") return;
  await prisma.timelineEvent.update({ where: { id }, data: { status: "ARCHIVED", archivedAt: new Date() } });
  revalidatePath("/timeline"); revalidatePath("/home");
}

export async function deleteTimelineEvent(id: string) {
  const user = await requireUser();
  const event = await prisma.timelineEvent.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!event || event.authorId !== user.id) throw new Error("Not allowed");
  if (event.status === "TRASHED") return;
  await prisma.timelineEvent.update({ where: { id }, data: { status: "TRASHED", deletedAt: new Date() } });
  revalidatePath("/timeline"); revalidatePath("/trash"); revalidatePath("/home");
}

export async function restoreTimelineEvent(id: string) {
  const user = await requireUser();
  const event = await prisma.timelineEvent.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!event || event.authorId !== user.id) throw new Error("Not allowed");
  if (event.status !== "TRASHED" && event.status !== "ARCHIVED") return;
  await prisma.timelineEvent.update({ where: { id }, data: { status: "ACTIVE", archivedAt: null, deletedAt: null } });
  revalidatePath("/timeline"); revalidatePath("/trash");
}

export async function permanentlyDeleteTimelineEvent(id: string) {
  const user = await requireUser();
  const event = await prisma.timelineEvent.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!event || event.authorId !== user.id || event.status !== "TRASHED") throw new Error("Not allowed");
  await prisma.timelineEvent.delete({ where: { id } });
  revalidatePath("/trash");
}

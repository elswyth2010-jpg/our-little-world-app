"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";

const schema = z.enum(["VINTAGE", "MIDNIGHT", "SAKURA", "DREAMY", "OCEAN", "MINIMAL"]);

export async function setTheme(formData: FormData) {
  const user = await requireUser();
  const theme = schema.parse(formData.get("theme"));
  await prisma.user.update({ where: { id: user.id }, data: { theme } });
  revalidatePath("/", "layout");
}

"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";

const diarySchema = z.object({
  title: z.string().trim().min(1).max(160),
  content: z.string().trim().min(1).max(50000),
  visibility: z.enum(["PRIVATE", "SHARED"]),
  entryDate: z.string().min(1)
});

function parseDiary(formData: FormData) {
  return diarySchema.parse({
    title: formData.get("title"),
    content: formData.get("content"),
    visibility: formData.get("visibility"),
    entryDate: formData.get("entryDate")
  });
}

export async function createDiaryEntry(formData: FormData) {
  const user = await requireUser();
  const data = parseDiary(formData);
  const entryDate = new Date(`${data.entryDate}T12:00:00`);

  if (Number.isNaN(entryDate.getTime())) throw new Error("Invalid diary date");

  await prisma.diaryEntry.create({
    data: {
      authorId: user.id,
      title: data.title,
      content: data.content,
      visibility: data.visibility,
      entryDate
    }
  });

  revalidatePath("/home");
  revalidatePath("/diary");
  redirect("/diary");
}

export async function updateDiaryEntry(id: string, formData: FormData) {
  const user = await requireUser();
  const data = parseDiary(formData);
  const entryDate = new Date(`${data.entryDate}T12:00:00`);

  const entry = await prisma.diaryEntry.findUnique({ where: { id }, select: { authorId: true } });
  if (!entry || entry.authorId !== user.id) throw new Error("Not allowed");
  if (Number.isNaN(entryDate.getTime())) throw new Error("Invalid diary date");

  await prisma.diaryEntry.update({
    where: { id },
    data: { title: data.title, content: data.content, visibility: data.visibility, entryDate }
  });

  revalidatePath("/home");
  revalidatePath("/diary");
  revalidatePath(`/diary/${id}/edit`);
  redirect("/diary");
}

export async function toggleDiaryFavorite(id: string) {
  const user = await requireUser();
  const entry = await prisma.diaryEntry.findUnique({ where: { id }, select: { id: true, authorId: true, visibility: true, status: true } });
  if (!entry || entry.status !== "ACTIVE" || (entry.authorId !== user.id && entry.visibility !== "SHARED")) throw new Error("Not allowed");

  const existing = await prisma.diaryFavorite.findUnique({ where: { userId_diaryEntryId: { userId: user.id, diaryEntryId: id } } });
  if (existing) {
    await prisma.diaryFavorite.delete({ where: { id: existing.id } });
  } else {
    await prisma.diaryFavorite.create({ data: { userId: user.id, diaryEntryId: id } });
  }

  revalidatePath("/diary");
  revalidatePath("/home");
}

export async function archiveDiaryEntry(id: string) {
  const user = await requireUser();
  const entry = await prisma.diaryEntry.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!entry || entry.authorId !== user.id) throw new Error("Not allowed");
  if (entry.status !== "ACTIVE") return;

  await prisma.diaryEntry.update({ where: { id }, data: { status: "ARCHIVED", archivedAt: new Date() } });
  revalidatePath("/diary");
  revalidatePath("/home");
}

export async function deleteDiaryEntry(id: string) {
  const user = await requireUser();
  const entry = await prisma.diaryEntry.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!entry || entry.authorId !== user.id) throw new Error("Not allowed");
  if (entry.status === "TRASHED") return;

  await prisma.diaryEntry.update({ where: { id }, data: { status: "TRASHED", deletedAt: new Date() } });
  revalidatePath("/diary");
  revalidatePath("/trash");
  revalidatePath("/home");
}

export async function restoreDiaryEntry(id: string) {
  const user = await requireUser();
  const entry = await prisma.diaryEntry.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!entry || entry.authorId !== user.id) throw new Error("Not allowed");
  if (entry.status !== "TRASHED" && entry.status !== "ARCHIVED") return;

  await prisma.diaryEntry.update({ where: { id }, data: { status: "ACTIVE", archivedAt: null, deletedAt: null } });
  revalidatePath("/diary");
  revalidatePath("/trash");
}

export async function permanentlyDeleteDiaryEntry(id: string) {
  const user = await requireUser();
  const entry = await prisma.diaryEntry.findUnique({ where: { id }, select: { authorId: true, status: true } });
  if (!entry || entry.authorId !== user.id || entry.status !== "TRASHED") throw new Error("Not allowed");

  await prisma.diaryEntry.delete({ where: { id } });
  revalidatePath("/trash");
}

"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";

const schema = z.object({
  title: z.string().trim().min(1).max(180),
  artist: z.string().trim().max(180).optional().default(""),
  coverUrl: z.string().trim().url().max(1000).optional().or(z.literal("")),
  externalUrl: z.string().trim().url().max(1000).optional().or(z.literal("")),
  note: z.string().trim().max(5000).optional().default(""),
  visibility: z.enum(["PRIVATE", "SHARED"]),
  diaryEntryIds: z.array(z.string()).default([]),
  memoryIds: z.array(z.string()).default([]),
});

export async function createSong(formData: FormData) {
  const user = await requireUser();
  const data = schema.parse({
    title: formData.get("title"), artist: formData.get("artist") ?? "",
    coverUrl: formData.get("coverUrl") ?? "", externalUrl: formData.get("externalUrl") ?? "",
    note: formData.get("note") ?? "", visibility: formData.get("visibility"),
    diaryEntryIds: formData.getAll("diaryEntryIds").map(String), memoryIds: formData.getAll("memoryIds").map(String),
  });

  const [diaries, memories] = await Promise.all([
    prisma.diaryEntry.findMany({ where: { id: { in: data.diaryEntryIds }, status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, select: { id: true } }),
    prisma.memory.findMany({ where: { id: { in: data.memoryIds }, status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, select: { id: true } }),
  ]);

  await prisma.song.create({
    data: {
      addedById: user.id, title: data.title, artist: data.artist || null, coverUrl: data.coverUrl || null,
      externalUrl: data.externalUrl || null, note: data.note || null, visibility: data.visibility,
      diaryLinks: { create: diaries.map(({ id }) => ({ diaryEntryId: id })) },
      memoryLinks: { create: memories.map(({ id }) => ({ memoryId: id })) },
    },
  });
  revalidatePath("/songs"); revalidatePath("/timeline"); revalidatePath("/home");
  redirect("/songs");
}

export async function archiveSong(id: string) {
  const user = await requireUser();
  const song = await prisma.song.findUnique({ where: { id }, select: { addedById: true, status: true } });
  if (!song || song.addedById !== user.id) throw new Error("Not allowed");
  if (song.status !== "ACTIVE") return;
  await prisma.song.update({ where: { id }, data: { status: "ARCHIVED", archivedAt: new Date() } });
  revalidatePath("/songs"); revalidatePath("/trash");
}

export async function deleteSong(id: string) {
  const user = await requireUser();
  const song = await prisma.song.findUnique({ where: { id }, select: { addedById: true, status: true } });
  if (!song || song.addedById !== user.id) throw new Error("Not allowed");
  if (song.status === "TRASHED") return;
  await prisma.song.update({ where: { id }, data: { status: "TRASHED", deletedAt: new Date() } });
  revalidatePath("/songs"); revalidatePath("/trash");
}

export async function restoreSong(id: string) {
  const user = await requireUser();
  const song = await prisma.song.findUnique({ where: { id }, select: { addedById: true, status: true } });
  if (!song || song.addedById !== user.id) throw new Error("Not allowed");
  if (!["TRASHED", "ARCHIVED"].includes(song.status)) return;
  await prisma.song.update({ where: { id }, data: { status: "ACTIVE", archivedAt: null, deletedAt: null } });
  revalidatePath("/songs"); revalidatePath("/trash");
}

export async function permanentlyDeleteSong(id: string) {
  const user = await requireUser();
  const song = await prisma.song.findUnique({ where: { id }, select: { addedById: true, status: true } });
  if (!song || song.addedById !== user.id || song.status !== "TRASHED") throw new Error("Not allowed");
  await prisma.song.delete({ where: { id } });
  revalidatePath("/trash");
}

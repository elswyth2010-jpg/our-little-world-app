"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";

const schema = z.object({
  title: z.string().trim().min(1).max(180),
  description: z.string().trim().max(10000).optional().default(""),
  category: z.string().trim().max(50).optional().default("EXPERIENCE"),
  status: z.enum(["DREAMING", "PLANNED", "COMPLETED"]),
  visibility: z.enum(["PRIVATE", "SHARED"]),
  targetDate: z.string().optional().default(""),
  priority: z.coerce.number().int().min(0).max(5).default(0),
});

function parse(data: FormData) {
  return schema.parse({
    title: data.get("title"),
    description: data.get("description") ?? "",
    category: data.get("category") ?? "EXPERIENCE",
    status: data.get("status") ?? "DREAMING",
    visibility: data.get("visibility") ?? "SHARED",
    targetDate: data.get("targetDate") ?? "",
    priority: data.get("priority") ?? 0,
  });
}

export async function createFuturePlan(formData: FormData) {
  const user = await requireUser();
  const data = parse(formData);
  const targetDate = data.targetDate ? new Date(`${data.targetDate}T12:00:00`) : null;
  if (targetDate && Number.isNaN(targetDate.getTime())) throw new Error("Invalid target date");

  await prisma.futurePlan.create({
    data: {
      createdById: user.id,
      title: data.title,
      description: data.description || null,
      category: data.category,
      status: data.status,
      visibility: data.visibility,
      targetDate,
      priority: data.priority,
      completedAt: data.status === "COMPLETED" ? new Date() : null,
    },
  });
  revalidatePath("/plans"); revalidatePath("/home");
  redirect("/plans");
}

export async function updateFuturePlan(id: string, formData: FormData) {
  const user = await requireUser();
  const existing = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, contentStatus: true } });
  if (!existing || existing.createdById !== user.id) throw new Error("Not allowed");
  if (existing.contentStatus === "TRASHED") throw new Error("Item is in Trash");
  const data = parse(formData);
  const targetDate = data.targetDate ? new Date(`${data.targetDate}T12:00:00`) : null;
  if (targetDate && Number.isNaN(targetDate.getTime())) throw new Error("Invalid target date");
  await prisma.futurePlan.update({
    where: { id },
    data: { title: data.title, description: data.description || null, category: data.category, status: data.status, visibility: data.visibility, targetDate, priority: data.priority, completedAt: data.status === "COMPLETED" ? (existing ? new Date() : null) : null },
  });
  revalidatePath("/plans"); revalidatePath(`/plans/${id}/edit`); revalidatePath("/home");
  redirect("/plans");
}

export async function markPlanCompleted(id: string) {
  const user = await requireUser();
  const plan = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, contentStatus: true } });
  if (!plan || plan.createdById !== user.id || plan.contentStatus !== "ACTIVE") throw new Error("Not allowed");
  await prisma.futurePlan.update({ where: { id }, data: { status: "COMPLETED", completedAt: new Date() } });
  revalidatePath("/plans"); revalidatePath("/home");
}

export async function reopenFuturePlan(id: string) {
  const user = await requireUser();
  const plan = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, contentStatus: true } });
  if (!plan || plan.createdById !== user.id || plan.contentStatus !== "ACTIVE") throw new Error("Not allowed");
  await prisma.futurePlan.update({ where: { id }, data: { status: "PLANNED", completedAt: null } });
  revalidatePath("/plans"); revalidatePath("/home");
}

export async function archiveFuturePlan(id: string) {
  const user = await requireUser();
  const plan = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, contentStatus: true } });
  if (!plan || plan.createdById !== user.id || plan.contentStatus !== "ACTIVE") throw new Error("Not allowed");
  await prisma.futurePlan.update({ where: { id }, data: { contentStatus: "ARCHIVED", archivedAt: new Date() } });
  revalidatePath("/plans"); revalidatePath("/trash");
}

export async function deleteFuturePlan(id: string) {
  const user = await requireUser();
  const plan = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, contentStatus: true } });
  if (!plan || plan.createdById !== user.id || plan.contentStatus === "TRASHED") throw new Error("Not allowed");
  await prisma.futurePlan.update({ where: { id }, data: { contentStatus: "TRASHED", deletedAt: new Date() } });
  revalidatePath("/plans"); revalidatePath("/trash");
}

export async function restoreFuturePlan(id: string) {
  const user = await requireUser();
  const plan = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, contentStatus: true } });
  if (!plan || plan.createdById !== user.id || !["TRASHED", "ARCHIVED"].includes(plan.contentStatus)) throw new Error("Not allowed");
  await prisma.futurePlan.update({ where: { id }, data: { contentStatus: "ACTIVE", archivedAt: null, deletedAt: null } });
  revalidatePath("/plans"); revalidatePath("/trash");
}

export async function permanentlyDeleteFuturePlan(id: string) {
  const user = await requireUser();
  const plan = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, contentStatus: true } });
  if (!plan || plan.createdById !== user.id || plan.contentStatus !== "TRASHED") throw new Error("Not allowed");
  await prisma.futurePlan.delete({ where: { id } });
  revalidatePath("/trash");
}

export async function turnPlanIntoMemory(id: string) {
  const user = await requireUser();
  const plan = await prisma.futurePlan.findUnique({ where: { id }, select: { createdById: true, title: true, description: true, targetDate: true, visibility: true, status: true, contentStatus: true } });
  if (!plan || plan.createdById !== user.id || plan.contentStatus !== "ACTIVE" || plan.status !== "COMPLETED") throw new Error("Only completed plans can become memories");
  const memory = await prisma.memory.create({ data: { authorId: user.id, title: plan.title, description: plan.description, visibility: plan.visibility, memoryDate: plan.targetDate ?? new Date() } });
  await prisma.timelineEvent.create({ data: { authorId: user.id, title: plan.title, description: "A completed future plan, remembered here.", category: "ADVENTURE", eventDate: plan.targetDate ?? new Date(), visibility: plan.visibility, memoryLinks: { create: { memoryId: memory.id } } } });
  revalidatePath("/plans"); revalidatePath("/memories"); revalidatePath("/timeline"); revalidatePath("/home");
  redirect(`/memories/${memory.id}`);
}

"use server";

import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";

const profileSchema = z.object({
  story: z.string().max(12000).default(""),
  anniversaryDate: z.string().optional(),
  favorites: z.string().max(6000).default(""),
  dreams: z.string().max(6000).default("")
});

const dateSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(1).max(120),
  date: z.string().min(1),
  note: z.string().max(500).optional()
});

function lines(value: string) {
  return value.split("\\n").map(v => v.trim()).filter(Boolean);
}

function favoriteItems(value: string) {
  return lines(value).map(line => {
    const [category, ...rest] = line.split("|");
    return { category: category.trim(), value: rest.join("|").trim() || category.trim() };
  });
}

export async function saveUsProfile(formData: FormData) {
  await requireUser();
  const parsed = profileSchema.parse({
    story: String(formData.get("story") ?? ""),
    anniversaryDate: String(formData.get("anniversaryDate") ?? ""),
    favorites: String(formData.get("favorites") ?? ""),
    dreams: String(formData.get("dreams") ?? "")
  });

  await prisma.usProfile.upsert({
    where: { id: "us" },
    create: {
      id: "us",
      story: parsed.story,
      anniversaryDate: parsed.anniversaryDate ? new Date(`${parsed.anniversaryDate}T00:00:00`) : null,
      favorites: favoriteItems(parsed.favorites),
      dreams: lines(parsed.dreams)
    },
    update: {
      story: parsed.story,
      anniversaryDate: parsed.anniversaryDate ? new Date(`${parsed.anniversaryDate}T00:00:00`) : null,
      favorites: favoriteItems(parsed.favorites),
      dreams: lines(parsed.dreams)
    }
  });
}

export async function saveImportantDate(formData: FormData) {
  const user = await requireUser();
  const parsed = dateSchema.parse({
    id: String(formData.get("id") || "") || undefined,
    title: String(formData.get("title") ?? ""),
    date: String(formData.get("date") ?? ""),
    note: String(formData.get("note") ?? "") || undefined
  });
  const data = { title: parsed.title, date: new Date(`${parsed.date}T00:00:00`), note: parsed.note ?? null, ownerId: user.id };
  if (parsed.id) {
    await prisma.importantDate.updateMany({ where: { id: parsed.id, ownerId: user.id }, data });
  } else {
    await prisma.importantDate.create({ data });
  }
}

export async function deleteImportantDate(formData: FormData) {
  const user = await requireUser();
  const id = String(formData.get("id") ?? "");
  await prisma.importantDate.deleteMany({ where: { id, ownerId: user.id } });
}

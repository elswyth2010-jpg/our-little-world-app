import { login } from "./actions";

export default function LoginPage() {
  return (
    <main className="page">
      <section className="card">
        <p className="muted">A private place for two.</p>
        <h1>Our Little World</h1>
        <p className="muted">Welcome back. ❤️</p>
        <form action={login}>
          <label className="field">
            <span>Email</span>
            <input name="email" type="email" autoComplete="email" required />
          </label>
          <label className="field">
            <span>Password</span>
            <input name="password" type="password" autoComplete="current-password" required />
          </label>
          <button className="button" type="submit">Enter</button>
        </form>
      </section>
    </main>
  );
}

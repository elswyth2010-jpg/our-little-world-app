import Link from "next/link";
import { requireUser } from "@/lib/auth/require-user";
import { PlanForm } from "@/components/plan-form";
export default async function NewPlanPage(){ await requireUser(); return <main className="app-shell"><header className="topbar"><Link className="brand" href="/plans">Our Future</Link><Link className="text-button" href="/plans">← Back</Link></header><section className="content-wrap narrow"><div className="page-heading"><p className="eyebrow">A little dream</p><h1>Add something to our future</h1><p className="muted">It can be a huge dream or something wonderfully small.</p></div><PlanForm/></section></main> }

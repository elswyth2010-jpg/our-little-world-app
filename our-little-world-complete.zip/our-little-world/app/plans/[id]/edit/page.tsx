import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { PlanForm } from "@/components/plan-form";
export default async function EditPlanPage({params}:{params:Promise<{id:string}>}){ const user=await requireUser(); const {id}=await params; const plan=await prisma.futurePlan.findUnique({where:{id}}); if(!plan||plan.createdById!==user.id||plan.contentStatus==="TRASHED")notFound(); return <main className="app-shell"><header className="topbar"><Link className="brand" href="/plans">Our Future</Link><Link className="text-button" href="/plans">← Back</Link></header><section className="content-wrap narrow"><div className="page-heading"><p className="eyebrow">Edit the plan</p><h1>{plan.title}</h1></div><PlanForm plan={plan}/></section></main> }

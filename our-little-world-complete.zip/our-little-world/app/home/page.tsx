import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { LogoutButton } from "@/components/logout-button";

export default async function HomePage() {
  const user = await requireUser();
  const [latestEntry, entryCount, sharedCount, latestTimeline] = await Promise.all([
    prisma.diaryEntry.findFirst({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, orderBy: { entryDate: "desc" }, select: { id: true, title: true, content: true, entryDate: true } }),
    prisma.diaryEntry.count({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] } }),
    prisma.diaryEntry.count({ where: { status: "ACTIVE", visibility: "SHARED" } }),
    prisma.timelineEvent.findFirst({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, orderBy: { eventDate: "desc" }, select: { title: true, eventDate: true } })
  ]);
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><nav><Link className="active" href="/home">Home</Link><Link href="/diary">Diary</Link><Link href="/memories">Memories</Link><Link href="/songs">Songs</Link><Link href="/timeline">Timeline</Link><Link href="/songs">Songs</Link><Link href="/plans">Future</Link><Link href="/us">Us</Link><Link href="/trash">Trash</Link></nav><LogoutButton /></header><section className="content-wrap home-grid"><div className="welcome-card"><p className="eyebrow">A little place for us</p><h1>Welcome back, {user.name}.</h1><p>Come in, put the world down for a moment, and keep a few memories safe.</p><div className="home-actions"><Link className="button" href="/diary/new">Write a page</Link><Link className="secondary-button" href="/diary">Open diary</Link></div></div><div className="stats-card"><div><strong>{entryCount}</strong><span>diary pages</span></div><div><strong>{sharedCount}</strong><span>shared pages</span></div></div>{latestEntry ? <article className="featured-entry"><p className="eyebrow">Latest page · {latestEntry.entryDate.toLocaleDateString("en-US", { month: "long", day: "numeric" })}</p><h2>{latestEntry.title}</h2><p>{latestEntry.content.length > 300 ? `${latestEntry.content.slice(0,300)}…` : latestEntry.content}</p><Link href="/diary">Read the diary →</Link></article> : <article className="featured-entry"><p className="eyebrow">Your first page</p><h2>There’s room for a story here.</h2><p>Write down something you never want to forget.</p><Link href="/diary/new">Start writing →</Link></article>}</section></main>;
}

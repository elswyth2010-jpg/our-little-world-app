import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { LogoutButton } from "@/components/logout-button";
import { UsForm } from "@/components/us-form";
import { deleteImportantDate, saveImportantDate } from "@/app/actions/us";

export default async function UsPage() {
  const user = await requireUser();
  const [partner, profile, dates, stats] = await Promise.all([
    prisma.user.findFirst({ where: { id: { not: user.id } }, select: { name: true, avatarUrl: true } }),
    prisma.usProfile.findUnique({ where: { id: "us" } }),
    prisma.importantDate.findMany({ orderBy: { date: "asc" }, take: 30 }),
    Promise.all([
      prisma.diaryEntry.count({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] } }),
      prisma.memory.count({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] } }),
      prisma.timelineEvent.count({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] } }),
      prisma.song.count({ where: { status: "ACTIVE", OR: [{ addedById: user.id }, { visibility: "SHARED" }] } }),
      prisma.futurePlan.count({ where: { contentStatus: "ACTIVE", OR: [{ createdById: user.id }, { visibility: "SHARED" }] } })
    ])
  ]);
  const favorites = Array.isArray(profile?.favorites) ? profile.favorites as {category:string; value:string}[] : [];
  const dreams = Array.isArray(profile?.dreams) ? profile.dreams as string[] : [];
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><nav><Link href="/home">Home</Link><Link href="/diary">Diary</Link><Link href="/memories">Memories</Link><Link href="/timeline">Timeline</Link><Link href="/songs">Songs</Link><Link href="/plans">Future</Link><Link className="active" href="/us">Us</Link><Link href="/trash">Trash</Link></nav><LogoutButton /></header>
    <section className="content-wrap us-page">
      <div className="page-heading"><div><p className="eyebrow">The two of us</p><h1>Our little world</h1><p className="muted">A quiet page for the story, dates, favorites, and dreams that belong to both of you.</p></div><Link className="button" href="/us/edit">Edit our page</Link></div>
      <section className="us-hero"><div className="us-names"><div className="person-badge">{user.name.slice(0,1).toUpperCase()}</div><span>{user.name}</span><span className="and">&</span><div className="person-badge">{(partner?.name ?? "Her").slice(0,1).toUpperCase()}</div><span>{partner?.name ?? "Her"}</span></div>{profile?.anniversaryDate && <p className="anniversary">Together since {new Date(profile.anniversaryDate).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}</p>}</section>
      <div className="us-grid">
        <article className="us-card us-story"><p className="eyebrow">Our Story</p><h2>The story so far</h2><p>{profile?.story || "This page is waiting for your story. Start with how it began, then add the tiny details you never want to forget."}</p></article>
        <article className="us-card"><p className="eyebrow">Our little archive</p><h2>What we've collected</h2><div className="us-stats">{[[stats[0],"diary pages"],[stats[1],"memories"],[stats[2],"timeline moments"],[stats[3],"songs"],[stats[4],"future plans"]].map(([n,l])=><div key={String(l)}><strong>{n}</strong><span>{l}</span></div>)}</div></article>
        <article className="us-card"><p className="eyebrow">Our Favorites</p><h2>Things we love</h2>{favorites.length ? <div className="favorite-list">{favorites.map((f,i)=><div className="favorite-item" key={`${f.category}-${i}`}><span>{f.category}</span><strong>{f.value}</strong></div>)}</div> : <p className="muted">Add favorite foods, movies, games, places, songs, or any tiny things that feel like you.</p>}</article>
        <article className="us-card"><p className="eyebrow">Our Dreams</p><h2>Things we want to do</h2>{dreams.length ? <ul className="dream-list">{dreams.map((d,i)=><li key={i}><span>✦</span>{d}</li>)}</ul> : <p className="muted">Your Future section can hold the detailed plans; this is the little list of dreams underneath them.</p>}</article>
      </div>
      <section className="us-card dates-card"><div className="section-heading"><div><p className="eyebrow">Important Dates</p><h2>Keep the days that matter</h2></div></div><div className="date-grid">{dates.map(d=><article className="date-item" key={d.id}><div><strong>{new Date(d.date).toLocaleDateString("en-US", { month:"short", day:"numeric" })}</strong><h3>{d.title}</h3><p>{d.note ?? ""}</p></div><form action={deleteImportantDate}><input type="hidden" name="id" value={d.id}/><button className="text-button danger" type="submit">Delete</button></form></article>)}</div><form action={saveImportantDate} className="date-form"><input name="title" placeholder="Date title" required/><input name="date" type="date" required/><input name="note" placeholder="Optional note"/><button className="button small-button" type="submit">Add date</button></form></section>
    </section></main>;
}

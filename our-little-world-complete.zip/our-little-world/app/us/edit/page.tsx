import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { LogoutButton } from "@/components/logout-button";
import { UsForm } from "@/components/us-form";

export default async function EditUsPage() {
  await requireUser();
  const profile = await prisma.usProfile.findUnique({ where: { id: "us" } });
  const favorites = Array.isArray(profile?.favorites) ? profile.favorites as {category:string; value:string}[] : [];
  const dreams = Array.isArray(profile?.dreams) ? profile.dreams as string[] : [];
  const favoritesText = favorites.map(f => `${f.category} | ${f.value}`).join("\n");
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><nav><Link href="/home">Home</Link><Link href="/diary">Diary</Link><Link href="/memories">Memories</Link><Link href="/timeline">Timeline</Link><Link href="/songs">Songs</Link><Link href="/plans">Future</Link><Link className="active" href="/us">Us</Link><Link href="/trash">Trash</Link></nav><LogoutButton /></header><section className="form-wrap"><p className="eyebrow">The two of us</p><h1>Edit our page</h1><p className="muted intro">This is the shared identity page for your little world. Keep it simple, personal, and change it whenever your story changes.</p><UsForm profile={profile} favoritesText={favoritesText} dreamsText={dreams.join("\n")} /><p style={{marginTop:18}}><Link className="secondary-button" href="/us">← Back to Us</Link></p></section></main>;
}

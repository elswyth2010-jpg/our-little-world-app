import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { TimelineForm } from "@/components/timeline-form";

export default async function NewTimelineEventPage() {
  const user = await requireUser();
  const [diaryEntries, memories, songs] = await Promise.all([
    prisma.diaryEntry.findMany({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, orderBy: { entryDate: "desc" }, select: { id: true, title: true, entryDate: true }, take: 40 }),
    prisma.memory.findMany({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, orderBy: { memoryDate: "desc" }, select: { id: true, title: true, memoryDate: true }, take: 40 }),
    prisma.song.findMany({ where: { status: "ACTIVE", OR: [{ addedById: user.id }, { visibility: "SHARED" }] }, orderBy: { createdAt: "desc" }, select: { id: true, title: true, artist: true }, take: 40 })
  ]);
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><Link className="secondary-button" href="/timeline">← Back to timeline</Link></header><section className="form-wrap"><p className="eyebrow">A chapter of us</p><h1>Add to the timeline</h1><p className="muted intro">Create a moment once, then connect the diary pages, memories, and songs that already belong to it.</p><TimelineForm diaryEntries={diaryEntries.map(e => ({id:e.id,title:e.title,date:e.entryDate}))} memories={memories.map(e => ({id:e.id,title:e.title,date:e.memoryDate}))} songs={songs} /></section></main>;
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/db/prisma";
import { getSessionUserId } from "@/lib/auth/session";
import { readPrivateFile } from "@/lib/storage/local";

export async function GET(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  const userId = await getSessionUserId();
  if (!userId) return new NextResponse("Unauthorized", { status: 401 });
  const { id } = await params;
  const media = await prisma.media.findUnique({ where: { id }, include: { memory: { select: { authorId: true, visibility: true, status: true } }, diaryEntry: { select: { authorId: true, visibility: true, status: true } } } });
  if (!media) return new NextResponse("Not found", { status: 404 });
  const content = media.memory ?? media.diaryEntry;
  if (!content || content.status === "TRASHED" || (content.authorId !== userId && content.visibility !== "SHARED")) return new NextResponse("Not found", { status: 404 });
  try {
    const bytes = await readPrivateFile(media.storageKey);
    return new NextResponse(bytes, { headers: { "Content-Type": media.mimeType, "Content-Disposition": `inline; filename="${media.filename.replace(/"/g, "")}"`, "Cache-Control": "private, max-age=300" } });
  } catch {
    return new NextResponse("Media unavailable", { status: 404 });
  }
}

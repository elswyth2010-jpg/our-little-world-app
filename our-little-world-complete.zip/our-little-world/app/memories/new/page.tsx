import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { MemoryForm } from "@/components/memory-form";

export default async function NewMemoryPage() {
  const user = await requireUser();
  const diaryEntries = await prisma.diaryEntry.findMany({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, orderBy: { entryDate: "desc" }, select: { id: true, title: true, entryDate: true }, take: 50 });
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><Link className="secondary-button" href="/memories">← Back to memories</Link></header><section className="form-wrap"><p className="eyebrow">A moment to keep</p><h1>Make a memory</h1><p className="muted intro">Give a favorite moment its own little place. Add photos, a clip, a voice note, and links back to the diary.</p><MemoryForm diaryEntries={diaryEntries} /></section></main>;
}

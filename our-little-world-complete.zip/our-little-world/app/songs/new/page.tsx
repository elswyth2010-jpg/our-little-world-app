import Link from "next/link";
import { prisma } from "@/lib/db/prisma";
import { requireUser } from "@/lib/auth/require-user";
import { SongForm } from "@/components/song-form";

export default async function NewSongPage() {
  const user = await requireUser();
  const [diaryEntries, memories] = await Promise.all([
    prisma.diaryEntry.findMany({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, orderBy: { entryDate: "desc" }, select: { id: true, title: true, entryDate: true }, take: 40 }),
    prisma.memory.findMany({ where: { status: "ACTIVE", OR: [{ authorId: user.id }, { visibility: "SHARED" }] }, orderBy: { memoryDate: "desc" }, select: { id: true, title: true, memoryDate: true }, take: 40 })
  ]);
  return <main className="app-shell"><header className="topbar"><Link className="brand" href="/home">Our Little World</Link><Link className="secondary-button" href="/songs">← Back to songs</Link></header><section className="form-wrap"><SongForm diaryEntries={diaryEntries.map(e=>({id:e.id,title:e.title,date:e.entryDate}))} memories={memories.map(e=>({id:e.id,title:e.title,date:e.memoryDate}))} /></section></main>;
}

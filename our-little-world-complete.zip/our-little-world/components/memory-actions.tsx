import { archiveMemory, deleteMemory } from "@/app/actions/memories";

export function MemoryActions({ id, canManage }: { id: string; canManage: boolean }) {
  if (!canManage) return null;
  return <div className="memory-actions"><form action={archiveMemory.bind(null, id)}><button className="text-button" type="submit">Archive</button></form><form action={deleteMemory.bind(null, id)}><button className="text-button danger" type="submit">Delete</button></form></div>;
}

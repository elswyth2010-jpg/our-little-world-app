import { createSong } from "@/app/actions/songs";

type Option = { id: string; title: string; date: Date };
export function SongForm({ diaryEntries, memories }: { diaryEntries: Option[]; memories: Option[] }) {
  return <form action={createSong} className="paper-form">
    <div className="song-form-hero"><div className="record-icon">♪</div><div><p className="eyebrow">Add a chapter to our soundtrack</p><h2>A song that belongs to us</h2><p className="muted">We store the song details and a legitimate listening link—not a copy of the music.</p></div></div>
    <label className="field"><span>Song title</span><input name="title" required maxLength={180} placeholder="The song that always reminds me of you" /></label>
    <div className="form-grid">
      <label className="field"><span>Artist</span><input name="artist" maxLength={180} placeholder="Artist name" /></label>
      <label className="field"><span>Visibility</span><select name="visibility" defaultValue="SHARED"><option value="SHARED">Shared — both of us</option><option value="PRIVATE">Private — only me</option></select></label>
    </div>
    <label className="field"><span>Cover artwork URL <small>optional</small></span><input name="coverUrl" type="url" placeholder="https://…" /></label>
    <label className="field"><span>Listening link <small>optional</small></span><input name="externalUrl" type="url" placeholder="A legitimate Spotify / YouTube / Apple Music link" /></label>
    <label className="field"><span>Why this song? <small>optional</small></span><textarea name="note" rows={5} maxLength={5000} placeholder="Write the little story behind this song." /></label>
    {diaryEntries.length > 0 && <fieldset className="link-picker"><legend>Connect diary pages</legend>{diaryEntries.map(e => <label key={e.id}><input type="checkbox" name="diaryEntryIds" value={e.id} /><span>{e.title}</span><small>{e.date.toLocaleDateString("en-US", {month:"short",day:"numeric",year:"numeric"})}</small></label>)}</fieldset>}
    {memories.length > 0 && <fieldset className="link-picker"><legend>Connect memories</legend>{memories.map(e => <label key={e.id}><input type="checkbox" name="memoryIds" value={e.id} /><span>{e.title}</span><small>{e.date.toLocaleDateString("en-US", {month:"short",day:"numeric",year:"numeric"})}</small></label>)}</fieldset>}
    <div className="form-footer"><a className="secondary-button" href="/songs">Cancel</a><button className="button" type="submit">Add to our soundtrack</button></div>
  </form>;
}

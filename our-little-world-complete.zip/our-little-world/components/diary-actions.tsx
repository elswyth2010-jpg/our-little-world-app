import { archiveDiaryEntry, deleteDiaryEntry, toggleDiaryFavorite } from "@/app/actions/diary";

export function DiaryActions({ id, favorite, canManage }: { id: string; favorite: boolean; canManage: boolean }) {
  return (
    <div className="entry-actions">
      <form action={toggleDiaryFavorite.bind(null, id)}>
        <button className="icon-button" type="submit" title={favorite ? "Remove favorite" : "Favorite"}>{favorite ? "★" : "☆"}</button>
      </form>
      {canManage && <a className="icon-button" href={`/diary/${id}/edit`} title="Edit">✎</a>}
      {canManage && <form action={archiveDiaryEntry.bind(null, id)}><button className="icon-button" type="submit" title="Archive">▱</button></form>}
      {canManage && <form action={deleteDiaryEntry.bind(null, id)}><button className="icon-button danger" type="submit" title="Move to trash">⌫</button></form>}
    </div>
  );
}

"use client";

import { useTransition } from "react";
import { setTheme } from "@/app/actions/theme";

const themes = [
  { id: "VINTAGE", name: "Vintage Diary", note: "Warm paper, ink & pressed flowers", mark: "✦" },
  { id: "MIDNIGHT", name: "Midnight", note: "Deep blue, quiet & cinematic", mark: "☾" },
  { id: "SAKURA", name: "Sakura", note: "Soft blush, cream & spring air", mark: "✿" },
  { id: "DREAMY", name: "Dreamy", note: "Lavender haze & soft starlight", mark: "⋆" },
  { id: "OCEAN", name: "Ocean", note: "Sea glass, blue & calm", mark: "≈" },
  { id: "MINIMAL", name: "Minimal", note: "Clean paper, quiet contrast", mark: "—" },
] as const;

export function ThemePicker({ current }: { current: string }) {
  const [pending, startTransition] = useTransition();
  return <div className="theme-picker-grid">
    {themes.map(theme => <form key={theme.id} action={formData => startTransition(() => setTheme(formData))}>
      <input type="hidden" name="theme" value={theme.id} />
      <button className={`theme-option ${current === theme.id ? "selected" : ""}`} type="submit" disabled={pending} aria-pressed={current === theme.id}>
        <span className="theme-swatch" data-preview-theme={theme.id}><i>{theme.mark}</i></span>
        <span className="theme-option-copy"><strong>{theme.name}</strong><small>{theme.note}</small></span>
        {current === theme.id && <span className="theme-check">✓</span>}
      </button>
    </form>)}
  </div>;
}

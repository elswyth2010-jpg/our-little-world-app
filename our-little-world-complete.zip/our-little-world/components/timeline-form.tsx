import { createTimelineEvent } from "@/app/actions/timeline";

type Option = { id: string; title: string; date: Date };
export function TimelineForm({ diaryEntries, memories, songs }: { diaryEntries: Option[]; memories: Option[]; songs: { id: string; title: string; artist: string | null }[] }) {
  const today = new Date().toISOString().slice(0, 10);
  return <form action={createTimelineEvent} className="paper-form">
    <label className="field"><span>Moment title</span><input name="title" required maxLength={160} placeholder="The day everything changed…" /></label>
    <label className="field"><span>What happened?</span><textarea name="description" maxLength={10000} rows={7} placeholder="Tell the story of this part of our journey." /></label>
    <div className="form-grid">
      <label className="field"><span>Date</span><input name="eventDate" type="date" required defaultValue={today} /></label>
      <label className="field"><span>Chapter type</span><select name="category" defaultValue="MILESTONE"><option value="BEGINNING">Beginning</option><option value="FIRST">First</option><option value="MILESTONE">Milestone</option><option value="ADVENTURE">Adventure</option><option value="CELEBRATION">Celebration</option><option value="OTHER">Other</option></select></label>
    </div>
    <label className="field"><span>Visibility</span><select name="visibility" defaultValue="SHARED"><option value="SHARED">Shared — both of us</option><option value="PRIVATE">Private — only me</option></select></label>
    {diaryEntries.length > 0 && <fieldset className="link-picker"><legend>Connect diary pages</legend>{diaryEntries.map((e) => <label key={e.id}><input type="checkbox" name="diaryEntryIds" value={e.id} /><span>{e.title}</span><small>{e.date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</small></label>)}</fieldset>}
    {memories.length > 0 && <fieldset className="link-picker"><legend>Connect memories</legend>{memories.map((e) => <label key={e.id}><input type="checkbox" name="memoryIds" value={e.id} /><span>{e.title}</span><small>{e.date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</small></label>)}</fieldset>}
    {songs.length > 0 && <fieldset className="link-picker"><legend>Connect songs</legend>{songs.map((s) => <label key={s.id}><input type="checkbox" name="songIds" value={s.id} /><span>{s.title}</span><small>{s.artist || "Song"}</small></label>)}</fieldset>}
    <div className="form-footer"><a className="secondary-button" href="/timeline">Cancel</a><button className="button" type="submit">Add to our story</button></div>
  </form>;
}

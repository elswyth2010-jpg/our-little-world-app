"use client";

import { useTransition } from "react";
import { archiveSong, deleteSong } from "@/app/actions/songs";

export function SongActions({ id, canManage }: { id: string; canManage: boolean }) {
  const [pending, start] = useTransition();
  if (!canManage) return null;
  return <div className="song-actions">
    <button className="text-button" disabled={pending} onClick={() => start(() => archiveSong(id))}>Archive</button>
    <button className="text-button danger" disabled={pending} onClick={() => { if (confirm("Move this song to Trash?")) start(() => deleteSong(id)); }}>Delete</button>
  </div>;
}

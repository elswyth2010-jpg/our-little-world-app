import { archiveTimelineEvent, deleteTimelineEvent } from "@/app/actions/timeline";

export function TimelineActions({ id, canManage }: { id: string; canManage: boolean }) {
  if (!canManage) return null;
  return <div className="timeline-actions"><form action={archiveTimelineEvent.bind(null, id)}><button className="text-button" type="submit">Archive</button></form><form action={deleteTimelineEvent.bind(null, id)}><button className="text-button danger" type="submit">Delete</button></form></div>;
}

import { saveUsProfile } from "@/app/actions/us";

export function UsForm({ profile, favoritesText, dreamsText }: { profile: any; favoritesText: string; dreamsText: string }) {
  return <form action={saveUsProfile} className="paper-form">
    <div className="field"><span>Our story</span><textarea name="story" rows={9} defaultValue={profile?.story ?? ""} placeholder="How did your story begin? What makes this little world yours?" /></div>
    <div className="form-grid">
      <div className="field"><span>Our special date</span><input name="anniversaryDate" type="date" defaultValue={profile?.anniversaryDate ? new Date(profile.anniversaryDate).toISOString().slice(0,10) : ""} /></div>
      <div className="field"><span>Favorites</span><textarea name="favorites" rows={5} defaultValue={favoritesText} placeholder="Food | your favorite place to eat\nMovie | the one you always rewatch\nGame | your favorite game" /><small>One per line. Use <b>Category | Favorite</b>.</small></div>
    </div>
    <div className="field"><span>Our dreams</span><textarea name="dreams" rows={6} defaultValue={dreamsText} placeholder="See the ocean together\nTry a new city\nHave a tiny photo booth moment" /><small>One dream per line.</small></div>
    <div className="form-footer"><button className="button" type="submit">Save our page</button></div>
  </form>;
}

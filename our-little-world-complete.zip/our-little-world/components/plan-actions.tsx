"use client";
import { useState } from "react";
import { archiveFuturePlan, deleteFuturePlan, markPlanCompleted, reopenFuturePlan, turnPlanIntoMemory } from "@/app/actions/plans";

export function PlanActions({ id, status, canManage }: { id: string; status: string; canManage: boolean }) {
  const [busy, setBusy] = useState(false);
  if (!canManage) return null;
  async function run(fn: (id: string) => Promise<void>) { setBusy(true); try { await fn(id); } finally { setBusy(false); } }
  return <div className="card-actions">
    {status !== "COMPLETED" ? <button disabled={busy} className="secondary-button" onClick={() => run(markPlanCompleted)}>Mark completed</button> : <><button disabled={busy} className="secondary-button" onClick={() => run(reopenFuturePlan)}>Reopen</button><form action={turnPlanIntoMemory}><input type="hidden" name="id" value={id}/><button className="button" type="submit">Turn into a memory ✦</button></form></>}
    <a className="text-button" href={`/plans/${id}/edit`}>Edit</a>
    <button disabled={busy} className="text-button" onClick={() => run(archiveFuturePlan)}>Archive</button>
    <button disabled={busy} className="text-button danger" onClick={() => run(deleteFuturePlan)}>Delete</button>
  </div>;
}

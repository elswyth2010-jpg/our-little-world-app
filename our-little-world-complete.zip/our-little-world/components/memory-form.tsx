import { createMemory } from "@/app/actions/memories";

type DiaryOption = { id: string; title: string; entryDate: Date };

export function MemoryForm({ diaryEntries }: { diaryEntries: DiaryOption[] }) {
  const today = new Date().toISOString().slice(0, 10);
  return (
    <form action={createMemory} className="paper-form" encType="multipart/form-data">
      <label className="field"><span>Memory title</span><input name="title" required maxLength={160} placeholder="The day we…" /></label>
      <label className="field"><span>Tell the story</span><textarea name="description" maxLength={10000} rows={7} placeholder="What do you want to remember about this moment?" /></label>
      <div className="form-grid">
        <label className="field"><span>Date</span><input name="memoryDate" type="date" required defaultValue={today} /></label>
        <label className="field"><span>Visibility</span><select name="visibility" defaultValue="SHARED"><option value="SHARED">Shared — both of us</option><option value="PRIVATE">Private — only me</option></select></label>
      </div>
      <label className="field"><span>Photos, videos, or audio</span><input name="media" type="file" accept="image/*,video/*,audio/*" multiple /><small>Up to 20MB per file in this development version.</small></label>
      {diaryEntries.length > 0 && <fieldset className="link-picker"><legend>Link diary pages</legend>{diaryEntries.map((entry) => <label key={entry.id}><input type="checkbox" name="diaryEntryIds" value={entry.id} /> <span>{entry.title}</span><small>{entry.entryDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</small></label>)}</fieldset>}
      <div className="form-footer"><a className="secondary-button" href="/memories">Cancel</a><button className="button" type="submit">Save memory</button></div>
    </form>
  );
}

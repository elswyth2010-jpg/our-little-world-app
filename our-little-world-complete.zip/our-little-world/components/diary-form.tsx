import { createDiaryEntry, updateDiaryEntry } from "@/app/actions/diary";

type Props = { mode: "create" | "edit"; id?: string; initial?: { title: string; content: string; visibility: "PRIVATE" | "SHARED"; entryDate: string } };

export function DiaryForm({ mode, id, initial }: Props) {
  const action = mode === "create" ? createDiaryEntry : updateDiaryEntry.bind(null, id!);
  return (
    <form action={action} className="paper-form">
      <label className="field"><span>Title</span><input name="title" required maxLength={160} defaultValue={initial?.title} placeholder="A little moment worth remembering…" /></label>
      <label className="field"><span>What happened?</span><textarea name="content" required maxLength={50000} defaultValue={initial?.content} placeholder="Write it down exactly how you want to remember it…" rows={12} /></label>
      <div className="form-grid">
        <label className="field"><span>Date</span><input name="entryDate" type="date" required defaultValue={initial?.entryDate} /></label>
        <label className="field"><span>Visibility</span><select name="visibility" defaultValue={initial?.visibility ?? "PRIVATE"}><option value="PRIVATE">Private — only me</option><option value="SHARED">Shared — both of us</option></select></label>
      </div>
      <div className="form-footer"><a className="secondary-button" href="/diary">Cancel</a><button className="button" type="submit">{mode === "create" ? "Save entry" : "Save changes"}</button></div>
    </form>
  );
}

import { createFuturePlan, updateFuturePlan } from "@/app/actions/plans";

export function PlanForm({ plan }: { plan?: { id:string; title:string; description:string|null; category:string; status:string; visibility:string; targetDate:Date|null; priority:number } }) {
  const action = plan ? updateFuturePlan.bind(null, plan.id) : createFuturePlan;
  return <form className="form-card" action={action}>
    <label>What do you want to do together?<input name="title" defaultValue={plan?.title ?? ""} required maxLength={180} placeholder="Visit the mountains" /></label>
    <label>Tell the story behind it<textarea name="description" defaultValue={plan?.description ?? ""} rows={6} maxLength={10000} placeholder="Why this matters to us..." /></label>
    <div className="form-grid">
      <label>Category<select name="category" defaultValue={plan?.category ?? "EXPERIENCE"}><option value="PLACE">Place</option><option value="FOOD">Food</option><option value="MOVIE">Movie</option><option value="GAME">Game</option><option value="EXPERIENCE">Experience</option><option value="DREAM">Dream</option><option value="OTHER">Other</option></select></label>
      <label>Status<select name="status" defaultValue={plan?.status ?? "DREAMING"}><option value="DREAMING">Dreaming</option><option value="PLANNED">Planned</option><option value="COMPLETED">Completed</option></select></label>
      <label>Target date<input type="date" name="targetDate" defaultValue={plan?.targetDate ? plan.targetDate.toISOString().slice(0,10) : ""} /></label>
      <label>Priority<select name="priority" defaultValue={String(plan?.priority ?? 0)}><option value="0">Someday</option><option value="1">Nice to have</option><option value="2">Important</option><option value="3">High</option><option value="4">Very high</option><option value="5">Top of our list</option></select></label>
    </div>
    <label>Visibility<select name="visibility" defaultValue={plan?.visibility ?? "SHARED"}><option value="SHARED">Shared — both of us</option><option value="PRIVATE">Private — only me</option></select></label>
    <button className="button" type="submit">{plan ? "Save plan" : "Add to our list"}</button>
  </form>;
}

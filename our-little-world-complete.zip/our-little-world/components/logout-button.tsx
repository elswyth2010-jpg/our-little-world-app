import { logout } from "@/app/actions/auth";

export function LogoutButton() {
  return (
    <form action={logout}>
      <button className="text-button" type="submit">Log out</button>
    </form>
  );
}
